<?php 
$config=mysqli_connect("localhost","root","","blog_web")
        or die ("Not Connected");
?>